
import React, {useEffect, useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Typography from '@material-ui/core/Typography';
import Slider from '@material-ui/core/Slider';

const useStyles = makeStyles({
  root: {
    width: 1000,
  },
});





const marks = [
  {
    value: 0,
    label: 'Dec 08 19',
  },
  {
    value: 20,
    label: 'b',
  },
  {
    value: 40,
    label: 'c',
  },
  {
    value: 60,
    label: 'd',
  },
  {
    value: 80,
    label: 'e',
  },
  {
    value: 100,
    label: 'f',
  },
];

function valuetext(value) {
  
  return `${value}°C`;
}

function valueLabelFormat(value) {
  return marks.findIndex((mark) => mark.value === value) + 1;
}
const handleChange = (event,newValue) => {
  return newValue
 
};


const DiscreteSlider = ({handleChange}) => {
  const classes = useStyles();
  const [patients, setPatients] = useState([]);
  useEffect(() => {
    fetch("https://maps.vnpost.vn/apps/covid19/api/patientapi/list")
        .then(res => res.json())
        .then(
            (result) => {
                setPatients(result.data);
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
                // setIsLoaded(true);
                // setError(error);
            }
        )
  }, []);

  return (
    <div className={classes.root}>

      <Typography id="discrete-slider-restrict" gutterBottom>
        Restricted values
      </Typography>
      <Slider
        defaultValue={0}
        
        getAriaValueText={valuetext}
        aria-labelledby="discrete-slider-restrict"
        step={null}
        valueLabelDisplay="auto"
        marks={marks}
        onChange={handleChange}
        
      />
    </div>
  );
}
export default  DiscreteSlider;