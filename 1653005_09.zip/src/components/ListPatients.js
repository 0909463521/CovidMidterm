import React, {useEffect, useState} from 'react';

import {compose, withProps} from "recompose"
import PatientInfo from './PatientInfo';
import Pagination from './Pagination'

const SimpleList = ({onPatientButtonClicked}) => {
    
    console.log('Rendering CovidGoogleMap...');
    const [patients, setPatients] = useState([]);
    const [loading ,setLoading]=useState(false);
    const [currentpage,setCurrentPage]=useState(1);
    const [postPerpage] =useState(60);

    useEffect(() => {
        fetch("https://maps.vnpost.vn/apps/covid19/api/patientapi/list")
            .then(res => res.json())
            .then(
                (result) => {
                    setPatients(result.data);
                    setLoading(false)
                },
                // Note: it's important to handle errors here
                // instead of a catch() block so that we don't swallow
                // exceptions from actual bugs in components.
                (error) => {
                    // setIsLoaded(true);
                    // setError(error);
                }
            )
    }, []);
    const indexOfLastPost = currentpage * postPerpage;
    const indexOfFirstPost = indexOfLastPost - postPerpage;
    const sortedPatients = patients.sort(function compare(a, b) {
        var dateA = new Date(a.verifyDate);
        var dateB = new Date(b.verifyDate);
        return dateA - dateB;
      }).reverse();
    const currentpatients = sortedPatients.slice(indexOfFirstPost,indexOfLastPost)

    const paginate = (pageNumber)=>{
        setCurrentPage(pageNumber)
    }
    
    
    const PatientsList = () => (
        
        
        <div>
        <h4>Danh sách các bệnh nhận</h4>
        <Pagination postsPerPage={postPerpage} totalPost={patients.length} paginate={paginate}/>
        <ul>
            
            {
                
                currentpatients.map((item,index) => (
                <li key={index}>
                <h5 color="red">
                Tên: {item.name}   
                </h5>
                <div>
                Thời Gian: {item.verifyDate}
                </div> 
                <button onClick={()=>{
                onPatientButtonClicked(item)}}>Xem Vị Trí</button>
                
                
                </li>
            
            ))} 
            
        </ul>
           
        </div>
      );
      return <PatientsList></PatientsList>
}
export default  SimpleList