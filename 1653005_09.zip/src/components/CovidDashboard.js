import React, {useEffect, useState} from 'react';
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";

import CovidGoogleMap from "./CovidGoogleMap";
import ListPatients from "./ListPatients";
import Container from "react-bootstrap/Container";
import PatientInfo from "./PatientInfo";
import 'bootstrap/dist/css/bootstrap.min.css';



const CovidDashboard = (props) => {
    const [currentPatient, setCurrentPatient] = useState();
  
    const patientMarkerClickedHandler = (patient) => {
        setCurrentPatient(patient);
    }
    const patientButtonClickedHandler = (patient) => {
        setCurrentPatient(patient);
    }


    console.log('Covid Dashboard render');

    return ( <Container>
        <Row>
            <Col xs={2} ><ListPatients onPatientButtonClicked={patientButtonClickedHandler} /></Col>  
            <Col xs={7} ><CovidGoogleMap onPatientMarkerClicked={patientMarkerClickedHandler} onLocationButtonClick={currentPatient} /></Col>
            <Col xs={3} >
                {currentPatient &&
                <PatientInfo patients={currentPatient}/>}
            </Col>
            
        </Row>
    </Container> )
};

export default CovidDashboard;